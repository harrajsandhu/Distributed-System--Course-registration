package client;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Frontclient{
	
	public static void main(String arg[]) throws Exception{
		System.out.println("Distributed Course Registration System\n");
		System.out.println("1-Advisor\n2-Student\n");
		 BufferedReader input=new BufferedReader(new InputStreamReader(System.in));
		String calvalue= input.readLine();
		int check=Integer.parseInt(calvalue);
		System.out.println(calvalue);
		if(check==1)
			Advisor.main(arg);
			
		else if(check==2)
			Student.main(arg);
		
		
		//StudentClient.main(arg);
	}
}
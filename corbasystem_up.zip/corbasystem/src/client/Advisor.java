package client;

import java.io.*;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;

import dcrsmodule.dcrsinterface;
import dcrsmodule.dcrsinterfaceHelper;



public class Advisor {
	private static int userstatus = 0;
	private static String userid;
	
	private static String Port(String ID){
		 
		 String portNbr = null;
		 final Matcher m1;
		 final Matcher m2;
		 final Matcher m3;
		 final Pattern p1;
		 final Pattern p2;
		 final Pattern p3;
		 
		 p1 = Pattern.compile("COMP");
		 p2 = Pattern.compile("SOEN");
		 p3 = Pattern.compile("INSE");	
		 m1 = p1.matcher(ID);
		 if(m1.lookingAt() == true) {
		 portNbr = "comp";
		 return portNbr;
		 }
		 m2 = p2.matcher(ID);
		 if(m2.lookingAt() == true) {
		 portNbr = "soen";
		 return portNbr;
		 }
		 m3 = p3.matcher(ID);
		 if(m3.lookingAt() == true) {
		 portNbr = "inse";
		 return portNbr;
		 }
		 System.out.println("Not right ID");
		return portNbr;
	}
	
	//User check for advisor method.
	private static int Identity(String ID){
	    userid = ID;  
		if("".equals(ID) || ID == null ){
	    	  	return userstatus;
	        }
	        if(ID.length()!=9){
	        	return userstatus;
	        }
	        if("A".equals(ID.substring(4,5))){
	            userstatus = 2;
	            return userstatus;
	        }
	        return userstatus;
	    }
	
	 public static void main(String args[]) throws Exception {
		 boolean check = true;
		 ORB orb = ORB.init(args, null);
			//-ORBInitialPort 1050 -ORBInitialHost localhost
			org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
			NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
		 System.out.println("Please input your ID:");
		
		 BufferedReader sin=new BufferedReader(new InputStreamReader(System.in));
		 String readline;
		 readline=sin.readLine();
		 //User check
		 Identity(readline);
		 String sername=Port(readline);
		 System.out.println("Welcome,"+ readline);
		 dcrsinterface obj = (dcrsinterface) dcrsinterfaceHelper.narrow(ncRef.resolve_str(sername));
		 obj.login(readline);
		 
		 while(check){
			 System.out.println("Please choose you action:\n"+"1.Add Course\n"+"2.Remove Course\n"+
		 "3.List Course Available\n"+"4.Enrol Course\n"+"5.Drop Course\n"+"6.Get Class Schedule\n"+"7.Exit");
			 readline = sin.readLine();
			 int n = Integer.parseInt(readline);
			 switch(n) {
			     case 1:
			    	 //add user check
			    	 if(userstatus == 2) {
			    	 System.out.println("Please input the course ID");
			    	 String courseID = sin.readLine();			    	 
			    	 System.out.println("Please input the semester");
			    	 String semester = sin.readLine();
			    	 System.out.println("Please input the capacity");
			    	 String cap = sin.readLine();
			    	 int capacity = Integer.parseInt(cap);
			    	 
			    	 System.out.println(obj.addCourse(courseID, semester,capacity));
					
			    	 check = true;
			    	 break;
			    	 }
			    	 System.out.println("You are not a advisor");
			    	 check = true;
			    	 break;
			     
			     case 2:
			    	 if(userstatus == 2) {
			    	 //add user check
			    	 System.out.println("Please input the semester");
			    	 String semester = sin.readLine();
			    	 System.out.println("Please input the course ID");
			    	 String courseID = sin.readLine();
			    	 System.out.println(obj.removeCourse(courseID, semester));
			    	 
			    	 check = true;
			    	 break;
			    	 }
			    	 System.out.println("You are not a advisor");
			    	 check = true;
			    	 break;

			     case 3:
			    	 if(userstatus == 2) {
			    		 //add user check
			    		 System.out.println("Please input semester");
			    		 String semester = sin.readLine();
			    		 System.out.println(obj.listCourseAvl(semester));
			    		
			    		 check = true;
			    		 break;
	    	         	}
	    	         	System.out.println("You are not a advisor");
	    	         	check = true;
	    	         	break;
			     
			     case 4:
			    	 if(userstatus > 0) {
			    		System.out.println("Please input student ID"); 
			    		String studentID = sin.readLine();
						//Student can only enrol course from their department server.
						if(userid.substring(0, 4).equals(studentID.substring(0, 4)) == false){
							System.out.println("You can not enrol course for student from other department.");
							check = true;
							break;
						}
			    		System.out.println("Please input course ID");
			    		String courseID = sin.readLine();
			    		System.out.println("Please input semester");
			    		String semester = sin.readLine();
			    		System.out.println(obj.enrolCourse(studentID, courseID, semester));
			    		
			    		check = true;
			    		break;
			    	 }
	    	         System.out.println("You have not login");
	    	         check = true;
	    	         break;
			     
			     case 5:
			    	 if(userstatus > 0) {
			    		 System.out.println("Please input student ID"); 
			    		 String studentID = sin.readLine();
						 if(userid.substring(0, 4).equals(studentID.substring(0, 4)) == false){
							 System.out.println("You can not drop course for student from other department.");
							 check = true;
							 break;
						 }
			    		 System.out.println("Please input course ID");
			    		 String courseID = sin.readLine();
			    		 System.out.println(obj.dropCourse(studentID, courseID));
			    		
			    	 check = true;
			    	 break;
			    	 }
	    	         System.out.println("You have not login");
	    	         check = true;
	    	         break;
			     
			     case 6:
			    	 if(userstatus > 0) {
			    		 System.out.println("Please input student ID"); 
			    		 String studentID = sin.readLine();
			    		 System.out.println(obj.getClassSche(studentID));
			    		
			    	 check = true;
			    	 break;
			    	 }
			    	 System.out.println("You have not login");
			    	 check = true;
			    	 break;
			     
			     case 7:
			         check = false;
			         break;
			     
			     default:
			    	 readline = sin.readLine();
			    	 System.out.println("No such function");
			    	 check = true;
			    	 break;
			 	}
			 }
		 System.out.println("Client shutdown");
		 System.exit(0);
	}
}

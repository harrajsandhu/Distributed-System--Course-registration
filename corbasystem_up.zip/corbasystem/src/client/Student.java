package client;

import java.io.*;



import org.omg.CORBA.ORB;
import org.omg.CosNaming.NamingContextExt;
import org.omg.CosNaming.NamingContextExtHelper;

import dcrsmodule.dcrsinterface;
import dcrsmodule.dcrsinterfaceHelper;

//import dcrsInterface.RemoteInterface;

public class Student {
	private static int userstatus = 0;
	private static String userid;
	

	private static String checkser(String ID) {
		 
		 String sername = null;
		 
		  boolean checkit= ID.contains("COMP");
		  boolean checkit1= ID.contains("SOEN");
		  boolean checkit2= ID.contains("INSE");
		
		 if(checkit == true) {
		 sername = "comp";
		 return sername;
		 }
		
		 if(checkit1 == true) {
		 sername = "soen";
		 return sername;
		 }
		 
		 if(checkit2 == true) {
		 sername = "inse";
		 return sername;
		 }
		 System.out.println("Not right ID");
		return sername;
	}
	
	//User check for advisor method.
	private static int Identity(String ID){
	    userid = ID;  
		if("".equals(ID) || ID == null ){
	    	  	return userstatus;
	        }
	        if(ID.length()!=9){
	        	return userstatus;
	        }
	        if("S".equals(ID.substring(4,5))){
	            userstatus = 1;
	            return userstatus;
	        }
	        return userstatus;
	    }
	
	 public static void main(String args[]) throws Exception {
		 ORB orb = ORB.init(args, null);
			//-ORBInitialPort 1050 -ORBInitialHost localhost
			org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
			NamingContextExt ncRef = NamingContextExtHelper.narrow(objRef);
		 boolean check = true;
		 System.out.println("Please input your ID:");
		
		 BufferedReader sin=new BufferedReader(new InputStreamReader(System.in));
		 String readline;
		 readline=sin.readLine();
		 //User check
		 Identity(readline);
		 String sername=checkser(readline);
		 System.out.println("Welcome,"+ readline);
		 //Registry registry = LocateRegistry.getRegistry(Port(readline));
		 dcrsinterface obj = (dcrsinterface) dcrsinterfaceHelper.narrow(ncRef.resolve_str(sername));
		 obj.login(readline);
		
		 while(check){
			 System.out.println("Please choose you action:\n"+"1.Enrol Course\n"+"2.Drop Course\n"+"3.Get Class Schedule\n"+"4.Swap Course\n"+"5.Exit");
			 readline = sin.readLine();
			 int n = Integer.parseInt(readline);
			 switch(n) {	     
			     case 1:
			    	 if(userstatus > 0) {
			    		System.out.println("Please input student ID"); 
			    		String studentID = sin.readLine();
						//Student can only enrol course from their department server.
						if(userid.equals(studentID) == false){
							System.out.println("You can not enrol course for other students.");
							
							check = true;
							break;
						}
			    		System.out.println("Please input course ID");
			    		String courseID = sin.readLine();
			    		System.out.println("Please input semester");
			    		String semester = sin.readLine();
			    		System.out.println(obj.enrolCourse(studentID, courseID, semester));
			    		
			    		check = true;
			    		break;
			    	 }
	    	         System.out.println("You have not login");
	    	         check = true;
	    	         break;
			     
			     case 2:
			    	 if(userstatus > 0) {
			    		 System.out.println("Please input student ID"); 
			    		 String studentID = sin.readLine();
						 if(userid.equals(studentID) == false){
							 System.out.println("You can not drop course for student from other department.");
							 check = true;
							 break;
						 }
			    		 System.out.println("Please input course ID");
			    		 String courseID = sin.readLine();
			    		 System.out.println(obj.dropCourse(studentID, courseID));
			    		 
			    	 check = true;
			    	 break;
			    	 }
	    	         System.out.println("You have not login");
	    	         check = true;
	    	         break;
			     
			     case 3:
			    	 if(userstatus > 0) {
			    		 System.out.println("Please input student ID"); 
			    		 String studentID = sin.readLine();
						 if(userid.equals(studentID) == false){
							 System.out.println("You can not list class schedule of other students.");
							 check = true;
							 break;
						 }
			    		 System.out.println(obj.getClassSche(studentID));
			    		
			    	 check = true;
			    	 break;
			    	 }
			    	 System.out.println("You have not login");
			    	 check = true;
			    	 break;
			     case 4:
			    	 if(userstatus > 0) {
				    		System.out.println("Please input student ID"); 
				    		String studentID = sin.readLine();
							//Student can only enrol course from their department server.
							if(userid.equals(studentID) == false){
								System.out.println("You can not swap course for other students.");
								
								check = true;
								break;
							}
				    		System.out.println("Please input the old course ID");
				    		String oldcourseID = sin.readLine();
				    		System.out.println("Please input the new course ID");
				    		String newcourseID = sin.readLine();
				    		System.out.println("Please input semester");
				    		String semester = sin.readLine();
				    		System.out.println(obj.swapCourse(studentID, oldcourseID,newcourseID, semester));
				    		
				    		check = true;
				    		break;
				    	 }
		    	         System.out.println("You have not login");
		    	         check = true;
			    	 break;
			     case 5:
			         check = false;
			         break;
			     
			     default:
			    	 readline = sin.readLine();
			    	 System.out.println("No such function");
			    	 check = true;
			    	 break;
			 	}
			 }
		 System.out.println("Client shutdown");
		 System.exit(0);
	}
}
